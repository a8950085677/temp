package com.example.parfentsev.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText editText1;
    TextView textView1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText1=(EditText)findViewById(R.id.ideditText1);
        textView1=(TextView)findViewById(R.id.idtextView1);
    }

    public void click1(View view) {
        String s1=editText1.getText().toString();
        double d1=Double.parseDouble(s1);
        d1=d1/8;
        s1=Double.toString(d1);
        editText1.setText(s1);
    }
}